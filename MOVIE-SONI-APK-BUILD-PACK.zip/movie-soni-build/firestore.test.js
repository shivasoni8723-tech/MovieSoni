const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read movies", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("movies").get());
});

test("Authenticated user: can read published movies", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("movies").doc("movie_pub").set({
      title: "Action Hero",
      description: "Exciting action movie",
      posterUrl: "https://example.com/poster.jpg",
      videoUrl: "https://example.com/video.mp4",
      durationMinutes: 120,
      language: "Hindi",
      category: "Action",
      priceInr: 49,
      isPublished: true,
      createdAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("movies").doc("movie_pub").get());
});

test("Authenticated non-admin: cannot read unpublished movie", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("movies").doc("movie_unpub").set({
      title: "Draft Movie",
      description: "Not yet released",
      posterUrl: "https://example.com/poster.jpg",
      videoUrl: "https://example.com/video.mp4",
      durationMinutes: 90,
      language: "Hindi",
      category: "Drama",
      priceInr: 29,
      isPublished: false,
      createdAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection("movies").doc("movie_unpub").get());
});

test("Admin: can create movies", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("admins").doc(ADMIN_UID).set({
      userId: ADMIN_UID,
      email: "admin@moviesoni.com",
      role: "admin",
      createdAt: new Date(),
    });
  });

  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  await assertSucceeds(
    adminDb.collection("movies").doc("movie_new").set({
      title: "Blockbuster Hit",
      description: "Amazing cinematic experience",
      posterUrl: "https://example.com/blockbuster.jpg",
      videoUrl: "https://example.com/blockbuster.mp4",
      durationMinutes: 145,
      language: "Hindi",
      category: "Thriller",
      priceInr: 99,
      isPublished: true,
      createdAt: new Date(),
    })
  );
});

test("Customer: cannot create movies", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("movies").doc("movie_hack").set({
      title: "Hacked Movie",
      description: "Unauthorized",
      posterUrl: "https://example.com/p.jpg",
      videoUrl: "https://example.com/v.mp4",
      durationMinutes: 100,
      language: "Hindi",
      category: "Action",
      priceInr: 0,
      isPublished: true,
      createdAt: new Date(),
    })
  );
});

test("Customer: can create a pending order for self", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("orders").doc("order_1").set({
      userId: ALICE_UID,
      movieId: "movie_123",
      movieTitle: "Action Movie",
      amountInr: 49,
      upiId: "moviesoni@upi",
      payeeName: "MOVIE SONI",
      upiUri: "upi://pay?pa=moviesoni@upi&pn=MOVIE%20SONI&am=49&cu=INR&tn=Movie%20Purchase&tr=order_1",
      status: "PENDING",
      createdAt: new Date(),
    })
  );
});

test("Customer: cannot approve an order", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("orders").doc("order_1").set({
      userId: ALICE_UID,
      movieId: "movie_123",
      movieTitle: "Action Movie",
      amountInr: 49,
      upiId: "moviesoni@upi",
      payeeName: "MOVIE SONI",
      upiUri: "upi://pay?pa=moviesoni@upi&pn=MOVIE%20SONI&am=49&cu=INR&tn=Movie%20Purchase&tr=order_1",
      status: "PENDING",
      createdAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("orders").doc("order_1").update({
      status: "APPROVED",
    })
  );
});

test("Customer: cannot read another user's purchase", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("purchases").doc("alice_movie123").set({
      userId: ALICE_UID,
      movieId: "movie_123",
      movieTitle: "Action Movie",
      orderId: "order_1",
      amountPaid: 49,
      createdAt: new Date(),
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("purchases").doc("alice_movie123").get());

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("purchases").doc("alice_movie123").get());
});
