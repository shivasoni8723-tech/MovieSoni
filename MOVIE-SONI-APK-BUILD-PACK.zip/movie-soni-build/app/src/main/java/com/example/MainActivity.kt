package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Movie
import com.example.data.repository.MovieRepository
import com.example.data.repository.OrderRepository
import com.example.data.repository.PurchaseRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.UserRepository
import com.example.ui.components.MovieSoniLogo
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminMovieUploadScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MovieDetailsScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.PurchasedMoviesScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.MovieSoniTheme
import com.example.ui.theme.TextMuted
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.AuthState
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.CustomerHomeViewModel
import com.example.ui.viewmodel.PaymentViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

sealed interface AppScreen {
    data object Home : AppScreen
    data class MovieDetails(val movie: Movie) : AppScreen
    data class Payment(val movie: Movie) : AppScreen
    data object PurchasedMovies : AppScreen
    data class Player(val movie: Movie, val isTrailer: Boolean) : AppScreen
    data object Search : AppScreen
    data object Settings : AppScreen
    data object AdminDashboard : AppScreen
    data class AdminMovieUpload(val movieToEdit: Movie? = null) : AppScreen
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val databaseId = getString(R.string.firestore_database_id)
        val firestore = FirebaseFirestore.getInstance(FirebaseApp.getInstance(), databaseId)

        val movieRepository = MovieRepository(firestore)
        val orderRepository = OrderRepository(firestore)
        val purchaseRepository = PurchaseRepository(firestore)
        val userRepository = UserRepository(firestore)
        val settingsRepository = SettingsRepository(firestore)

        val authViewModel = AuthViewModel(userRepository)
        val adminViewModel = AdminViewModel(
            movieRepository = movieRepository,
            orderRepository = orderRepository,
            userRepository = userRepository,
            settingsRepository = settingsRepository
        )

        setContent {
            MovieSoniTheme {
                val authState by authViewModel.authState.collectAsState()

                when (val state = authState) {
                    is AuthState.Loading -> {
                        SplashScreen()
                    }

                    is AuthState.Unauthenticated, is AuthState.Error -> {
                        AuthScreen(authViewModel = authViewModel)
                    }

                    is AuthState.Authenticated -> {
                        val homeViewModel = remember(state.user.uid) {
                            CustomerHomeViewModel(
                                movieRepository = movieRepository,
                                purchaseRepository = purchaseRepository,
                                settingsRepository = settingsRepository,
                                userId = state.user.uid
                            )
                        }

                        MovieSoniAppNavigator(
                            userId = state.user.uid,
                            userName = state.user.displayName.orEmpty().ifBlank { state.profile?.displayName.orEmpty() },
                            userEmail = state.user.email.orEmpty(),
                            userPhotoUrl = state.user.photoUrl?.toString() ?: state.profile?.photoUrl,
                            isAdmin = state.isAdmin,
                            authViewModel = authViewModel,
                            homeViewModel = homeViewModel,
                            adminViewModel = adminViewModel,
                            movieRepository = movieRepository,
                            orderRepository = orderRepository,
                            purchaseRepository = purchaseRepository,
                            settingsRepository = settingsRepository
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MovieSoniAppNavigator(
    userId: String,
    userName: String,
    userEmail: String,
    userPhotoUrl: String?,
    isAdmin: Boolean,
    authViewModel: AuthViewModel,
    homeViewModel: CustomerHomeViewModel,
    adminViewModel: AdminViewModel,
    movieRepository: MovieRepository,
    orderRepository: OrderRepository,
    purchaseRepository: PurchaseRepository,
    settingsRepository: SettingsRepository
) {
    val context = LocalContext.current
    val backStack = remember { mutableStateListOf<AppScreen>(AppScreen.Home) }
    val currentScreen = backStack.lastOrNull() ?: AppScreen.Home

    fun navigateTo(screen: AppScreen) {
        backStack.add(screen)
    }

    fun navigateBack() {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.lastIndex)
        }
    }

    Crossfade(targetState = currentScreen, label = "screen_crossfade") { screen ->
        when (screen) {
            is AppScreen.Home -> {
                HomeScreen(
                    homeViewModel = homeViewModel,
                    onMovieClick = { movie -> navigateTo(AppScreen.MovieDetails(movie)) },
                    onSearchClick = { navigateTo(AppScreen.Search) },
                    onPurchasedClick = { navigateTo(AppScreen.PurchasedMovies) },
                    onSettingsClick = { navigateTo(AppScreen.Settings) }
                )
            }

            is AppScreen.MovieDetails -> {
                MovieDetailsScreen(
                    movie = screen.movie,
                    userId = userId,
                    purchaseRepository = purchaseRepository,
                    onBack = { navigateBack() },
                    onBuyNow = { movie -> navigateTo(AppScreen.Payment(movie)) },
                    onPlayMovie = { movie -> navigateTo(AppScreen.Player(movie, isTrailer = false)) },
                    onPlayTrailer = { movie -> navigateTo(AppScreen.Player(movie, isTrailer = true)) }
                )
            }

            is AppScreen.Payment -> {
                val paymentViewModel = remember(screen.movie.id) {
                    PaymentViewModel(
                        orderRepository = orderRepository,
                        settingsRepository = settingsRepository,
                        purchaseRepository = purchaseRepository,
                        userId = userId,
                        userName = userName,
                        userEmail = userEmail,
                        movie = screen.movie
                    )
                }

                PaymentScreen(
                    viewModel = paymentViewModel,
                    onBack = { navigateBack() },
                    onWatchMovie = { movie ->
                        navigateBack()
                        navigateTo(AppScreen.Player(movie, isTrailer = false))
                    }
                )
            }

            is AppScreen.PurchasedMovies -> {
                PurchasedMoviesScreen(
                    userId = userId,
                    purchaseRepository = purchaseRepository,
                    movieRepository = movieRepository,
                    onBack = { navigateBack() },
                    onMovieClick = { movie -> navigateTo(AppScreen.MovieDetails(movie)) },
                    onWatchMovie = { movie -> navigateTo(AppScreen.Player(movie, isTrailer = false)) },
                    onExploreMovies = {
                        backStack.clear()
                        backStack.add(AppScreen.Home)
                    }
                )
            }

            is AppScreen.Player -> {
                PlayerScreen(
                    movie = screen.movie,
                    isTrailer = screen.isTrailer,
                    userId = userId,
                    purchaseRepository = purchaseRepository,
                    onBack = { navigateBack() },
                    onUnlockNow = { movie ->
                        navigateBack()
                        navigateTo(AppScreen.Payment(movie))
                    }
                )
            }

            is AppScreen.Search -> {
                SearchScreen(
                    movieRepository = movieRepository,
                    onBack = { navigateBack() },
                    onMovieClick = { movie -> navigateTo(AppScreen.MovieDetails(movie)) }
                )
            }

            is AppScreen.Settings -> {
                SettingsScreen(
                    userName = userName,
                    userEmail = userEmail,
                    userPhotoUrl = userPhotoUrl,
                    userId = userId,
                    isAdmin = isAdmin,
                    onBack = { navigateBack() },
                    onNavigateToAdmin = { navigateTo(AppScreen.AdminDashboard) },
                    onNavigateToPurchased = { navigateTo(AppScreen.PurchasedMovies) },
                    onSignOut = {
                        authViewModel.signOut(context)
                    }
                )
            }

            is AppScreen.AdminDashboard -> {
                AdminDashboardScreen(
                    viewModel = adminViewModel,
                    onBack = { navigateBack() },
                    onNavigateToUploadMovie = { movie -> navigateTo(AppScreen.AdminMovieUpload(movie)) }
                )
            }

            is AppScreen.AdminMovieUpload -> {
                AdminMovieUploadScreen(
                    movieToEdit = screen.movieToEdit,
                    viewModel = adminViewModel,
                    onBack = { navigateBack() }
                )
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            MovieSoniLogo(size = 110)
            Spacer(modifier = Modifier.height(24.dp))
            CircularProgressIndicator(
                color = BrandRed,
                strokeWidth = 3.dp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Connecting to MOVIE SONI Cloud...",
                color = TextMuted,
                fontSize = 12.sp
            )
        }
    }
}
