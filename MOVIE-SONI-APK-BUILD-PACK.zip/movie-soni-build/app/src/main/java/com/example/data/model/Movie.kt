package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Movie(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val posterUrl: String = "",
    val videoUrl: String = "",
    val trailerUrl: String? = null,
    val durationMinutes: Long = 0L,
    val releaseDate: String = "",
    val language: String = "Hindi",
    val category: String = "Action",
    val priceInr: Long = 49L,
    val isPublished: Boolean = true,
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false,
    val isLatest: Boolean = false,
    val isComingSoon: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
