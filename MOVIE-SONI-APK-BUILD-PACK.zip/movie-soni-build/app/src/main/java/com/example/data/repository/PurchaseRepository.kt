package com.example.data.repository

import com.example.data.model.Purchase
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class PurchaseRepository(private val db: FirebaseFirestore) {

    fun observeUserPurchases(userId: String): Flow<List<Purchase>> {
        return db.collection("purchases")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Purchase::class.java)
            }
    }

    suspend fun isPurchased(userId: String, movieId: String): Boolean {
        val docId = "${userId}_$movieId"
        val path = "purchases/$docId"
        return try {
            val doc = db.collection("purchases").document(docId).get().await()
            doc.exists()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            false
        }
    }
}
