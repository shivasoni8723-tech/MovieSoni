package com.example.data.repository

import com.example.data.model.AppSettings
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class SettingsRepository(private val db: FirebaseFirestore) {

    fun observeSettings(): Flow<AppSettings> {
        return db.collection("app_settings").document("general")
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(AppSettings::class.java) ?: AppSettings()
                } else {
                    AppSettings()
                }
            }
    }

    suspend fun getSettings(): AppSettings {
        val path = "app_settings/general"
        return try {
            val doc = db.collection("app_settings").document("general").get().await()
            if (doc.exists()) doc.toObject(AppSettings::class.java) ?: AppSettings() else AppSettings()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            AppSettings()
        }
    }

    suspend fun updateSettings(settings: AppSettings): Result<Unit> {
        val docRef = db.collection("app_settings").document("general")
        val path = docRef.path
        val payload = mapOf(
            "upiId" to settings.upiId.trim(),
            "payeeName" to settings.payeeName.trim(),
            "supportEmail" to settings.supportEmail.trim(),
            "supportPhone" to (settings.supportPhone?.trim()?.ifBlank { null }),
            "bannerMovieId" to (settings.bannerMovieId?.trim()?.ifBlank { null }),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        return try {
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }
}
