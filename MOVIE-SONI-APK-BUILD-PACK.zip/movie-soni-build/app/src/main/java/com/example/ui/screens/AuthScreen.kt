package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.viewmodel.AuthState
import com.example.ui.viewmodel.AuthViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private const val GRID_COUNT = 5
private const val TOTAL_ANIMATION_SEC = 4.2f

private data class LogoFragmentSpec(
    val row: Int,
    val col: Int,
    val scatterXNorm: Float,
    val scatterYNorm: Float,
    val initRotX: Float,
    val initRotY: Float,
    val initRotZ: Float,
    val initScale: Float,
    val driftPhase: Float
)

private data class GlowParticleSpec(
    val angleRad: Float,
    val radiusNorm: Float,
    val sizeDp: Float,
    val color: Color,
    val speedFactor: Float,
    val phase: Float
)

@Composable
fun AuthScreen(
    authViewModel: AuthViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val isLoading by authViewModel.isLoading.collectAsState()
    val authState by authViewModel.authState.collectAsState()

    var animationFinished by rememberSaveable { mutableStateOf(false) }
    val timeline = remember { Animatable(if (animationFinished) TOTAL_ANIMATION_SEC else 0f) }

    LaunchedEffect(Unit) {
        authViewModel.attemptAutoSignIn(context)
        if (!animationFinished) {
            timeline.animateTo(
                targetValue = TOTAL_ANIMATION_SEC,
                animationSpec = tween(durationMillis = 4200, easing = LinearEasing)
            )
            animationFinished = true
        }
    }

    LaunchedEffect(authState) {
        if (authState is AuthState.Error) {
            val message = (authState as AuthState.Error).message
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        }
    }

    // Load scaled source texture from the official uploaded logo for fragment animation
    val fragmentSourceBitmap: ImageBitmap? = remember(context) {
        try {
            val raw = BitmapFactory.decodeResource(context.resources, R.drawable.ic_movie_soni_logo)
            if (raw != null) {
                val targetPx = 360
                val scaled = if (raw.width != targetPx || raw.height != targetPx) {
                    Bitmap.createScaledBitmap(raw, targetPx, targetPx, true)
                } else {
                    raw
                }
                scaled.asImageBitmap()
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    val fragments = remember { buildFragmentSpecs() }
    val particles = remember { buildParticleSpecs() }
    val flyEasing = remember { CubicBezierEasing(0.62f, 0.0f, 0.22f, 1.0f) }

    val t = timeline.value

    // Step calculations (0.0 - 4.2s)
    // Step 1: 0.0 - 0.5s -> invisible
    // Step 2: 0.5 - 1.5s -> scattered pieces + particles fade in
    // Step 3: 1.5 - 2.8s -> fly to center + rotate + motion blur
    // Step 4: 2.8 - 3.3s -> join + flash + blue/purple glow
    // Step 5: 3.3 - 3.8s -> gentle bounce + settle stationary
    // Step 6: 3.8 - 4.2s -> Google button fade in

    val piecesVisible = t in 0.5f..2.86f
    val assembledVisible = t >= 2.8f

    val appearProgress = ((t - 0.5f) / 1.0f).coerceIn(0f, 1f)
    val flyRaw = ((t - 1.5f) / 1.3f).coerceIn(0f, 1f)
    val flyProgress = flyEasing.transform(flyRaw)
    val motionBlurFactor = if (t in 1.5f..2.8f) sin(flyRaw * PI).toFloat() else 0f

    val piecesAlpha = when {
        t < 0.5f -> 0f
        t < 1.5f -> FastOutSlowInEasing.transform(appearProgress)
        t <= 2.8f -> 1f
        t <= 2.86f -> 1f - ((t - 2.8f) / 0.06f).coerceIn(0f, 1f)
        else -> 0f
    }

    val assembledAlpha = when {
        t < 2.8f -> 0f
        t < 2.88f -> ((t - 2.8f) / 0.08f).coerceIn(0f, 1f)
        else -> 1f
    }

    // Step 4 flash & glow (2.8 - 3.8s, fully stops by 3.8s)
    val flashProgress = ((t - 2.8f) / 0.5f).coerceIn(0f, 1f)
    val flashAlpha = if (t in 2.8f..3.3f) {
        if (flashProgress < 0.25f) {
            flashProgress / 0.25f
        } else {
            (1f - (flashProgress - 0.25f) / 0.75f).coerceIn(0f, 1f)
        }
    } else {
        0f
    }

    val auraAlpha = when {
        t in 2.8f..3.3f -> 0.55f * flashProgress
        t in 3.3f..3.8f -> 0.55f * (1f - ((t - 3.3f) / 0.5f).coerceIn(0f, 1f))
        else -> 0f
    }

    // Step 5 single gentle bounce (3.3 - 3.8s)
    val logoScale = if (t in 3.3f..3.8f) {
        val bp = ((t - 3.3f) / 0.5f).coerceIn(0f, 1f)
        when {
            bp < 0.38f -> {
                val sub = FastOutSlowInEasing.transform(bp / 0.38f)
                1f + 0.075f * sub
            }
            bp < 0.74f -> {
                val sub = FastOutSlowInEasing.transform((bp - 0.38f) / 0.36f)
                1.075f - 0.09f * sub
            }
            else -> {
                val sub = FastOutSlowInEasing.transform((bp - 0.74f) / 0.26f)
                0.985f + 0.015f * sub
            }
        }
    } else {
        1f
    }

    // Step 6 button fade in (3.8 - 4.2s)
    val buttonProgress = FastOutSlowInEasing.transform(((t - 3.8f) / 0.4f).coerceIn(0f, 1f))
    val buttonEnabled = buttonProgress >= 0.9f && !isLoading

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val screenWidthPx = with(density) { maxWidth.toPx() }
        val screenHeightPx = with(density) { maxHeight.toPx() }
        val logoSizeDp = (minOf(maxWidth, maxHeight) * 0.46f).coerceIn(170.dp, 260.dp)
        val logoSizePx = with(density) { logoSizeDp.toPx() }
        val tileSizeDp = logoSizeDp / GRID_COUNT

        // Logo center-upper vertical ratio matches Column weights: 0.85f top / 1.15f bottom
        val logoCenterY = screenHeightPx * 0.41f
        val logoCenterX = screenWidthPx * 0.5f

        // Background glowing particles & assembly flash canvas
        if (t in 0.5f..3.85f) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(logoCenterX, logoCenterY)

                // Soft blue & purple particles during scatter + assembly (0.5s - 3.2s)
                if (t in 0.5f..3.25f) {
                    val particleFadeIn = ((t - 0.5f) / 0.6f).coerceIn(0f, 1f)
                    val particleFadeOut = if (t > 2.65f) (1f - (t - 2.65f) / 0.6f).coerceIn(0f, 1f) else 1f
                    val pAlphaGlobal = particleFadeIn * particleFadeOut

                    val maxScatterRadius = minOf(size.width, size.height) * 0.46f
                    val convergeFactor = if (t < 1.5f) {
                        0f
                    } else {
                        flyEasing.transform(((t - 1.5f) / 1.4f).coerceIn(0f, 1f))
                    }

                    particles.forEach { p ->
                        val angle = p.angleRad + (t - 0.5f) * p.speedFactor * 0.45f
                        val radius = maxScatterRadius * p.radiusNorm * (1f - convergeFactor * 0.88f)
                        val px = center.x + cos(angle) * radius
                        val py = center.y + sin(angle) * radius
                        val pulse = 0.65f + 0.35f * sin((t * 4f + p.phase).toDouble()).toFloat()
                        val dotRadius = with(density) { p.sizeDp.dp.toPx() }

                        drawCircle(
                            color = p.color.copy(alpha = 0.22f * pAlphaGlobal * pulse),
                            radius = dotRadius * 2.8f,
                            center = Offset(px, py)
                        )
                        drawCircle(
                            color = p.color.copy(alpha = 0.85f * pAlphaGlobal * pulse),
                            radius = dotRadius,
                            center = Offset(px, py)
                        )
                    }
                }

                // Subtle radial aura behind the reconstructed logo (2.8s - 3.8s)
                if (auraAlpha > 0.005f) {
                    val auraRadius = logoSizePx * 1.15f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                NeonBlue.copy(alpha = auraAlpha * 0.65f),
                                NeonPurple.copy(alpha = auraAlpha * 0.45f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = auraRadius
                        ),
                        radius = auraRadius,
                        center = center
                    )
                }

                // Light flash & expanding blue-purple ring on assembly (2.8s - 3.3s)
                if (flashAlpha > 0.005f) {
                    val flashRadius = logoSizePx * (0.75f + flashProgress * 0.8f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = flashAlpha * 0.5f),
                                NeonBlue.copy(alpha = flashAlpha * 0.45f),
                                NeonPurple.copy(alpha = flashAlpha * 0.3f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = flashRadius
                        ),
                        radius = flashRadius,
                        center = center
                    )

                    val ringRadius = logoSizePx * (0.48f + flashProgress * 0.85f)
                    drawCircle(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                NeonBlue.copy(alpha = flashAlpha * 0.85f),
                                NeonPurple.copy(alpha = flashAlpha * 0.85f),
                                NeonBlue.copy(alpha = flashAlpha * 0.85f)
                            ),
                            center = center
                        ),
                        radius = ringRadius,
                        center = center,
                        style = Stroke(width = with(density) { (4f * (1f - flashProgress * 0.6f)).dp.toPx() })
                    )
                }
            }
        }

        // Main Responsive Column containing ONLY: 1. Animated Logo, 2. Sign in with Google button
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.weight(0.85f))

            // 1. Official MOVIE SONI Logo (Fragment Assembly -> Exact Original Logo)
            Box(
                modifier = Modifier.size(logoSizeDp),
                contentAlignment = Alignment.Center
            ) {
                // Fragmented 3D assembly phase (0.5s - 2.86s)
                if (piecesVisible && fragmentSourceBitmap != null && piecesAlpha > 0.005f) {
                    val srcTileW = fragmentSourceBitmap.width / GRID_COUNT
                    val srcTileH = fragmentSourceBitmap.height / GRID_COUNT
                    val tilePx = logoSizePx / GRID_COUNT
                    val maxSpreadX = screenWidthPx * 0.38f
                    val maxSpreadY = screenHeightPx * 0.30f

                    fragments.forEach { frag ->
                        val gridOffsetX = (frag.col - (GRID_COUNT - 1) / 2f) * tilePx
                        val gridOffsetY = (frag.row - (GRID_COUNT - 1) / 2f) * tilePx

                        val scatterX = frag.scatterXNorm * maxSpreadX
                        val scatterY = frag.scatterYNorm * maxSpreadY

                        // Gentle hover drift during step 2 (0.5 - 1.5s)
                        val driftWeight = (1f - flyProgress) * appearProgress
                        val driftX = sin((t * 2.5f + frag.driftPhase).toDouble()).toFloat() * tilePx * 0.16f * driftWeight
                        val driftY = cos((t * 2.2f + frag.driftPhase).toDouble()).toFloat() * tilePx * 0.16f * driftWeight

                        val curOffsetX = (scatterX * (1f - flyProgress)) + driftX
                        val curOffsetY = (scatterY * (1f - flyProgress)) + driftY
                        val curRotX = frag.initRotX * (1f - flyProgress)
                        val curRotY = frag.initRotY * (1f - flyProgress)
                        val curRotZ = frag.initRotZ * (1f - flyProgress)
                        val curScale = frag.initScale + (1f - frag.initScale) * flyProgress

                        // Cinematic motion-blur trails during Step 3 flight
                        if (motionBlurFactor > 0.04f) {
                            val trailCount = 2
                            for (echo in 1..trailCount) {
                                val lag = echo * 0.09f * motionBlurFactor
                                val echoProgress = (flyProgress - lag).coerceIn(0f, 1f)
                                val echoOffsetX = scatterX * (1f - echoProgress)
                                val echoOffsetY = scatterY * (1f - echoProgress)
                                val echoAlpha = piecesAlpha * motionBlurFactor * (0.28f / echo)

                                FragmentTile(
                                    source = fragmentSourceBitmap,
                                    srcX = frag.col * srcTileW,
                                    srcY = frag.row * srcTileH,
                                    srcW = srcTileW,
                                    srcH = srcTileH,
                                    tileSizeDp = tileSizeDp,
                                    tx = gridOffsetX + echoOffsetX,
                                    ty = gridOffsetY + echoOffsetY,
                                    rotX = frag.initRotX * (1f - echoProgress),
                                    rotY = frag.initRotY * (1f - echoProgress),
                                    rotZ = frag.initRotZ * (1f - echoProgress),
                                    scale = frag.initScale + (1f - frag.initScale) * echoProgress,
                                    alpha = echoAlpha,
                                    cameraDist = 12f * density.density
                                )
                            }
                        }

                        FragmentTile(
                            source = fragmentSourceBitmap,
                            srcX = frag.col * srcTileW,
                            srcY = frag.row * srcTileH,
                            srcW = srcTileW,
                            srcH = srcTileH,
                            tileSizeDp = tileSizeDp,
                            tx = gridOffsetX + curOffsetX,
                            ty = gridOffsetY + curOffsetY,
                            rotX = curRotX,
                            rotY = curRotY,
                            rotZ = curRotZ,
                            scale = curScale,
                            alpha = piecesAlpha,
                            cameraDist = 12f * density.density
                        )
                    }
                }

                // Reconstructed Official Original Logo (2.8s onwards, exact unmodified image)
                if (assembledVisible) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_movie_soni_logo),
                        contentDescription = "MOVIE SONI Official Logo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                alpha = assembledAlpha
                                scaleX = logoScale
                                scaleY = logoScale
                            }
                            .testTag("app_official_logo")
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // 2. Sign in with Google Button (Fades in cleanly at 3.8 - 4.2s)
            Button(
                onClick = {
                    authViewModel.signInWithGoogle(context)
                },
                enabled = buttonEnabled,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF1F1F1F),
                    disabledContainerColor = Color.White,
                    disabledContentColor = Color(0xFF1F1F1F)
                ),
                shape = RoundedCornerShape(28.dp),
                contentPadding = PaddingValues(horizontal = 24.dp),
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .fillMaxWidth(0.84f)
                    .height(54.dp)
                    .offset(y = ((1f - buttonProgress) * 18f).dp)
                    .graphicsLayer {
                        alpha = buttonProgress
                    }
                    .testTag("google_sign_in_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color(0xFF1F1F1F),
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_google_g),
                            contentDescription = "Google",
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Sign in with Google",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1F1F1F)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1.15f))
        }
    }
}

@Composable
private fun FragmentTile(
    source: ImageBitmap,
    srcX: Int,
    srcY: Int,
    srcW: Int,
    srcH: Int,
    tileSizeDp: androidx.compose.ui.unit.Dp,
    tx: Float,
    ty: Float,
    rotX: Float,
    rotY: Float,
    rotZ: Float,
    scale: Float,
    alpha: Float,
    cameraDist: Float
) {
    Canvas(
        modifier = Modifier
            .size(tileSizeDp)
            .graphicsLayer {
                translationX = tx
                translationY = ty
                rotationX = rotX
                rotationY = rotY
                rotationZ = rotZ
                scaleX = scale
                scaleY = scale
                this.alpha = alpha
                cameraDistance = cameraDist
            }
    ) {
        drawImage(
            image = source,
            srcOffset = IntOffset(srcX, srcY),
            srcSize = IntSize(srcW, srcH),
            dstOffset = IntOffset.Zero,
            dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt())
        )
    }
}

private fun buildFragmentSpecs(): List<LogoFragmentSpec> {
    val specs = mutableListOf<LogoFragmentSpec>()
    val center = (GRID_COUNT - 1) / 2f
    for (row in 0 until GRID_COUNT) {
        for (col in 0 until GRID_COUNT) {
            val idx = row * GRID_COUNT + col
            val dx = col - center
            val dy = row - center
            // Deterministic cinematic scatter with radial outward bias + golden-angle variation
            val angle = idx * 2.39996f
            val baseRadius = 0.45f + ((idx * 37) % 55) / 100f
            val scatterX = (dx * 0.24f + cos(angle) * baseRadius).coerceIn(-1.05f, 1.05f)
            val scatterY = (dy * 0.24f + sin(angle) * baseRadius).coerceIn(-1.05f, 1.05f)

            val rotX = (((idx * 53) % 180) - 90).toFloat()
            val rotY = (((idx * 71) % 180) - 90).toFloat()
            val rotZ = (((idx * 97) % 300) - 150).toFloat()
            val scale = 0.58f + ((idx * 19) % 62) / 100f
            val driftPhase = (idx * 0.75f)

            specs.add(
                LogoFragmentSpec(
                    row = row,
                    col = col,
                    scatterXNorm = scatterX,
                    scatterYNorm = scatterY,
                    initRotX = rotX,
                    initRotY = rotY,
                    initRotZ = rotZ,
                    initScale = scale,
                    driftPhase = driftPhase
                )
            )
        }
    }
    return specs
}

private fun buildParticleSpecs(): List<GlowParticleSpec> {
    val palette = listOf(
        NeonBlue,
        Color(0xFF00B0FF),
        NeonPurple,
        Color(0xFFC04CFD),
        Color(0xFF6A5ACD)
    )
    return List(36) { idx ->
        GlowParticleSpec(
            angleRad = idx * 0.58f,
            radiusNorm = 0.28f + ((idx * 29) % 72) / 100f,
            sizeDp = 2.0f + ((idx * 13) % 25) / 10f,
            color = palette[idx % palette.size],
            speedFactor = if (idx % 2 == 0) 1f else -0.8f,
            phase = idx * 0.43f
        )
    }
}
