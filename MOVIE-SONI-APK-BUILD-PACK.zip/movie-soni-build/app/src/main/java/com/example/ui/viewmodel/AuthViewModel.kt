package com.example.ui.viewmodel

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.UserProfile
import com.example.data.repository.UserRepository
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

sealed interface AuthState {
    data object Loading : AuthState
    data object Unauthenticated : AuthState
    data class Authenticated(val user: FirebaseUser, val profile: UserProfile?, val isAdmin: Boolean) : AuthState
    data class Error(val message: String) : AuthState
}

class AuthViewModel(
    private val userRepository: UserRepository
) : ViewModel() {

    private val auth: FirebaseAuth = Firebase.auth

    private val _authState = MutableStateFlow<AuthState>(AuthState.Loading)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private var authListener: FirebaseAuth.AuthStateListener? = null

    init {
        authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                checkUserStatusAndSync(user)
            } else {
                _authState.value = AuthState.Unauthenticated
                _isAdmin.value = false
            }
        }
        auth.addAuthStateListener(authListener!!)
    }

    private fun checkUserStatusAndSync(user: FirebaseUser) {
        viewModelScope.launch {
            val email = user.email.orEmpty()
            try {
                val isAdminUser = userRepository.checkIsAdmin(user.uid, email)
                _isAdmin.value = isAdminUser

                val syncResult = userRepository.syncUserProfile(
                    userId = user.uid,
                    email = email,
                    displayName = user.displayName.orEmpty(),
                    photoUrl = user.photoUrl?.toString()
                )
                val profile = syncResult.getOrNull()
                if (profile?.isBlocked == true && !isAdminUser) {
                    _authState.value = AuthState.Error("Your account has been suspended by administration. Contact support.")
                    auth.signOut()
                } else {
                    _authState.value = AuthState.Authenticated(user, profile, isAdminUser)
                }
            } catch (e: Exception) {
                Log.w("AuthViewModel", "Sync user profile error: ${e.message}")
                _authState.value = AuthState.Authenticated(user, null, email.equals("zoyaaiassistant0@gmail.com", true))
            }
        }
    }

    fun attemptAutoSignIn(context: Context) {
        if (auth.currentUser != null) {
            checkUserStatusAndSync(auth.currentUser!!)
            return
        }

        val clientId = getWebClientId(context)
        if (clientId.isNullOrBlank()) {
            _authState.value = AuthState.Unauthenticated
            return
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(true)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        val credentialManager = CredentialManager.create(context)
        viewModelScope.launch {
            try {
                val result = credentialManager.getCredential(context, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    auth.signInWithCredential(authCredential).await()
                } else {
                    _authState.value = AuthState.Unauthenticated
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Unauthenticated
            }
        }
    }

    fun signInWithGoogle(context: Context) {
        val clientId = getWebClientId(context)
        if (clientId.isNullOrBlank()) {
            _authState.value = AuthState.Error("Enable Google Sign-In & add SHA-1 in Firebase Console, then update google-services.json")
            return
        }

        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()

        val credentialManager = CredentialManager.create(context)
        _isLoading.value = true

        viewModelScope.launch {
            try {
                val activity = context as? Activity
                    ?: throw IllegalStateException("Context must be an Activity for interactive Google Sign-In")
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    auth.signInWithCredential(authCredential).await()
                } else {
                    _authState.value = AuthState.Error("Unexpected credential type received")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("AuthViewModel", "Google Sign-In cancelled: ${e.message}")
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Sign-in error: ${e.message}", e)
                _authState.value = AuthState.Error(e.localizedMessage ?: "Sign-in failed")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun signOut(context: Context) {
        val credentialManager = CredentialManager.create(context)
        viewModelScope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w("AuthViewModel", "Failed to clear credential state: ${e.message}")
                } finally {
                    auth.signOut()
                    _authState.value = AuthState.Unauthenticated
                    _isAdmin.value = false
                }
            }
        }
    }

    private fun getWebClientId(context: Context): String? {
        return try {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) context.getString(resId).takeIf { it.isNotBlank() } else null
        } catch (_: Exception) {
            null
        }
    }

    override fun onCleared() {
        super.onCleared()
        authListener?.let { auth.removeAuthStateListener(it) }
    }
}
