package com.example.data.util

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object QrCodeGenerator {
    fun buildUpiUri(
        upiId: String,
        payeeName: String,
        amountInr: Long,
        orderId: String,
        movieTitle: String
    ): String {
        val encodedPayee = URLEncoder.encode(payeeName, StandardCharsets.UTF_8.toString()).replace("+", "%20")
        val cleanNote = ("Movie: " + movieTitle.take(20)).filter { it.isLetterOrDigit() || it == ' ' }
        val encodedNote = URLEncoder.encode(cleanNote, StandardCharsets.UTF_8.toString()).replace("+", "%20")
        return "upi://pay?pa=$upiId&pn=$encodedPayee&am=$amountInr&cu=INR&tn=$encodedNote&tr=$orderId"
    }

    fun generateQrBitmap(content: String, size: Int = 512): Bitmap {
        val hints = mapOf(
            EncodeHintType.MARGIN to 1,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        return bitmap
    }
}
