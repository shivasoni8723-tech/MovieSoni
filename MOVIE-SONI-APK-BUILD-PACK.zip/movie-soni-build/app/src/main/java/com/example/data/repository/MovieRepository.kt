package com.example.data.repository

import com.example.data.model.Movie
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class MovieRepository(private val db: FirebaseFirestore) {

    fun observePublishedMovies(): Flow<List<Movie>> {
        return db.collection("movies")
            .whereEqualTo("isPublished", true)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Movie::class.java)
            }
    }

    fun observeAllMoviesAdmin(): Flow<List<Movie>> {
        return db.collection("movies")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Movie::class.java)
            }
    }

    suspend fun getMovie(movieId: String): Movie? {
        val path = "movies/$movieId"
        return try {
            val doc = db.collection("movies").document(movieId).get().await()
            if (doc.exists()) doc.toObject(Movie::class.java) else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }

    suspend fun createMovie(movie: Movie): Result<String> {
        val docRef = db.collection("movies").document()
        val path = docRef.path
        val payload = mapOf(
            "title" to movie.title.trim(),
            "description" to movie.description.trim(),
            "posterUrl" to movie.posterUrl.trim(),
            "videoUrl" to movie.videoUrl.trim(),
            "trailerUrl" to (movie.trailerUrl?.trim()?.ifBlank { null }),
            "durationMinutes" to movie.durationMinutes,
            "releaseDate" to movie.releaseDate.trim(),
            "language" to movie.language.trim(),
            "category" to movie.category.trim(),
            "priceInr" to movie.priceInr,
            "isPublished" to movie.isPublished,
            "isFeatured" to movie.isFeatured,
            "isTrending" to movie.isTrending,
            "isLatest" to movie.isLatest,
            "isComingSoon" to movie.isComingSoon,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateMovie(movieId: String, movie: Movie): Result<Unit> {
        val docRef = db.collection("movies").document(movieId)
        val path = docRef.path
        val payload = mapOf(
            "title" to movie.title.trim(),
            "description" to movie.description.trim(),
            "posterUrl" to movie.posterUrl.trim(),
            "videoUrl" to movie.videoUrl.trim(),
            "trailerUrl" to (movie.trailerUrl?.trim()?.ifBlank { null }),
            "durationMinutes" to movie.durationMinutes,
            "releaseDate" to movie.releaseDate.trim(),
            "language" to movie.language.trim(),
            "category" to movie.category.trim(),
            "priceInr" to movie.priceInr,
            "isPublished" to movie.isPublished,
            "isFeatured" to movie.isFeatured,
            "isTrending" to movie.isTrending,
            "isLatest" to movie.isLatest,
            "isComingSoon" to movie.isComingSoon,
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        return try {
            docRef.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteMovie(movieId: String): Result<Unit> {
        val docRef = db.collection("movies").document(movieId)
        val path = docRef.path
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
