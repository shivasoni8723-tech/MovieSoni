package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Movie
import com.example.ui.components.LiveSyncBadge
import com.example.ui.components.MovieCard
import com.example.ui.components.MovieSoniLogo
import com.example.ui.theme.BrandGold
import com.example.ui.theme.BrandRed
import com.example.ui.theme.CardDark
import com.example.ui.theme.CardStroke
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.CustomerHomeViewModel
import com.example.ui.viewmodel.HomeUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    homeViewModel: CustomerHomeViewModel,
    onMovieClick: (Movie) -> Unit,
    onSearchClick: () -> Unit,
    onPurchasedClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by homeViewModel.uiState.collectAsState()
    val isRefreshing by homeViewModel.isRefreshing.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepBlack
                ),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MovieSoniLogo(size = 36)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MOVIE SONI",
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "YOUR ENTERTAINMENT",
                                color = BrandGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                },
                actions = {
                    LiveSyncBadge(modifier = Modifier.padding(end = 4.dp))
                    IconButton(
                        onClick = onSearchClick,
                        modifier = Modifier.testTag("home_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Movies",
                            tint = TextWhite
                        )
                    }
                    IconButton(
                        onClick = onPurchasedClick,
                        modifier = Modifier.testTag("home_purchased_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Purchased Movies",
                            tint = BrandGold
                        )
                    }
                    IconButton(
                        onClick = onSettingsClick,
                        modifier = Modifier.testTag("home_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TextWhite
                        )
                    }
                }
            )
        },
        containerColor = DeepBlack,
        modifier = modifier.testTag("customer_home_screen")
    ) { innerPadding ->
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { homeViewModel.refresh() },
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = uiState) {
                is HomeUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = BrandRed)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Synchronizing movies from cloud...",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                is HomeUiState.Empty -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            MovieSoniLogo(size = 80)
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = "NO MOVIES AVAILABLE RIGHT NOW.",
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "When Admin uploads and publishes movies from the integrated Admin Panel, they will appear here automatically without updating your APK.",
                                color = TextMuted,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = { homeViewModel.refresh() },
                                colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = BrandGold)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Check for New Movies", color = TextWhite)
                            }
                        }
                    }
                }
                is HomeUiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = state.message,
                                color = BrandRed,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { homeViewModel.refresh() },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandRed)
                            ) {
                                Text("Retry Cloud Sync")
                            }
                        }
                    }
                }
                is HomeUiState.Success -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 32.dp)
                    ) {
                        // 1. Featured Hero Banner
                        item {
                            state.bannerMovie?.let { hero ->
                                HeroBanner(
                                    movie = hero,
                                    onMovieClick = { onMovieClick(hero) }
                                )
                            }
                        }

                        // 2. Categories Horizontal Bar
                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(state.categories) { cat ->
                                    val isSelected = cat == state.selectedCategory
                                    Surface(
                                        color = if (isSelected) BrandRed else CardDark,
                                        shape = RoundedCornerShape(20.dp),
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelected) BrandRed else CardStroke
                                        ),
                                        modifier = Modifier.clickable { homeViewModel.setCategory(cat) }
                                    ) {
                                        Text(
                                            text = cat,
                                            color = if (isSelected) TextWhite else TextMuted,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 3. My Purchased Movies (if any)
                        if (state.purchasedMovies.isNotEmpty()) {
                            item {
                                MovieSectionHeader(
                                    title = "My Purchased Movies",
                                    subtitle = "Pay once, watch forever"
                                )
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(state.purchasedMovies, key = { "purchased_${it.id}" }) { movie ->
                                        MovieCard(
                                            movie = movie,
                                            isPurchased = true,
                                            onClick = { onMovieClick(movie) }
                                        )
                                    }
                                }
                            }
                        }

                        // 4. Featured Movies
                        if (state.featuredMovies.isNotEmpty()) {
                            item {
                                MovieSectionHeader(title = "Featured Movies")
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(state.featuredMovies, key = { "featured_${it.id}" }) { movie ->
                                        MovieCard(
                                            movie = movie,
                                            isPurchased = state.purchasedMovies.any { it.id == movie.id },
                                            onClick = { onMovieClick(movie) }
                                        )
                                    }
                                }
                            }
                        }

                        // 5. Latest Releases
                        if (state.latestMovies.isNotEmpty()) {
                            item {
                                MovieSectionHeader(title = "Latest Releases")
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(state.latestMovies, key = { "latest_${it.id}" }) { movie ->
                                        MovieCard(
                                            movie = movie,
                                            isPurchased = state.purchasedMovies.any { it.id == movie.id },
                                            onClick = { onMovieClick(movie) }
                                        )
                                    }
                                }
                            }
                        }

                        // 6. Trending Movies
                        if (state.trendingMovies.isNotEmpty()) {
                            item {
                                MovieSectionHeader(title = "Trending Movies")
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(state.trendingMovies, key = { "trending_${it.id}" }) { movie ->
                                        MovieCard(
                                            movie = movie,
                                            isPurchased = state.purchasedMovies.any { it.id == movie.id },
                                            onClick = { onMovieClick(movie) }
                                        )
                                    }
                                }
                            }
                        }

                        // 7. Coming Soon
                        if (state.comingSoonMovies.isNotEmpty()) {
                            item {
                                MovieSectionHeader(
                                    title = "Coming Soon",
                                    subtitle = "Premieres releasing soon on MOVIE SONI"
                                )
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(state.comingSoonMovies, key = { "soon_${it.id}" }) { movie ->
                                        MovieCard(
                                            movie = movie,
                                            isPurchased = false,
                                            onClick = { onMovieClick(movie) }
                                        )
                                    }
                                }
                            }
                        }

                        // 8. All Movies
                        item {
                            MovieSectionHeader(
                                title = if (state.selectedCategory == "All") "All Movies" else "${state.selectedCategory} Movies",
                                subtitle = "${state.allMovies.size} titles available"
                            )
                        }

                        // Grid-like items
                        val chunked = state.allMovies.chunked(2)
                        items(chunked) { pair ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                for (movie in pair) {
                                    MovieCard(
                                        movie = movie,
                                        isPurchased = state.purchasedMovies.any { it.id == movie.id },
                                        onClick = { onMovieClick(movie) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (pair.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroBanner(
    movie: Movie,
    onMovieClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .clickable(onClick = onMovieClick)
            .testTag("hero_banner")
    ) {
        if (movie.posterUrl.isNotBlank()) {
            AsyncImage(
                model = movie.posterUrl,
                contentDescription = movie.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF2E1045), DeepBlack)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                MovieSoniLogo(size = 80)
            }
        }

        // Gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.5f),
                            DeepBlack
                        ),
                        startY = 50f
                    )
                )
        )

        // Banner content
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Surface(
                color = BrandRed,
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "FEATURED SPOTLIGHT",
                    color = TextWhite,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = movie.title,
                color = TextWhite,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${movie.category} • ${movie.language.uppercase()} • ${movie.durationMinutes}m",
                    color = BrandGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row {
                Button(
                    onClick = onMovieClick,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TextWhite)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (movie.priceInr > 0) "Watch / Buy ₹${movie.priceInr}" else "Watch Free",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun MovieSectionHeader(
    title: String,
    subtitle: String? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = title,
            color = TextWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        if (!subtitle.isNullOrBlank()) {
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}
