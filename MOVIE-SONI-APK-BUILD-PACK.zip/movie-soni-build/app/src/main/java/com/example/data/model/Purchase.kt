package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Purchase(
    @DocumentId val id: String = "",
    val userId: String = "",
    val movieId: String = "",
    val movieTitle: String = "",
    val moviePosterUrl: String? = null,
    val orderId: String = "",
    val amountPaid: Long = 0L,
    @ServerTimestamp val purchaseDate: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)
