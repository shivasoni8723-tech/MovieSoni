package com.example.ui.viewmodel

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Movie
import com.example.data.model.Order
import com.example.data.repository.OrderRepository
import com.example.data.repository.PurchaseRepository
import com.example.data.repository.SettingsRepository
import com.example.data.util.QrCodeGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface PaymentUiState {
    data object Loading : PaymentUiState
    data class Ready(
        val orderId: String,
        val movie: Movie,
        val amountInr: Long,
        val upiId: String,
        val payeeName: String,
        val upiUri: String,
        val qrBitmap: Bitmap,
        val transactionRef: String?,
        val status: String,
        val rejectionReason: String?,
        val isSubmittingRef: Boolean
    ) : PaymentUiState
    data class Completed(val movie: Movie, val orderId: String) : PaymentUiState
    data class Error(val message: String) : PaymentUiState
}

class PaymentViewModel(
    private val orderRepository: OrderRepository,
    private val settingsRepository: SettingsRepository,
    private val purchaseRepository: PurchaseRepository,
    private val userId: String,
    private val userName: String,
    private val userEmail: String,
    private val movie: Movie
) : ViewModel() {

    private val _uiState = MutableStateFlow<PaymentUiState>(PaymentUiState.Loading)
    val uiState: StateFlow<PaymentUiState> = _uiState.asStateFlow()

    private var currentOrderId: String? = null

    init {
        initiateOrder()
    }

    private fun initiateOrder() {
        viewModelScope.launch {
            _uiState.value = PaymentUiState.Loading

            // Check if already purchased
            if (purchaseRepository.isPurchased(userId, movie.id)) {
                _uiState.value = PaymentUiState.Completed(movie, "ALREADY_PURCHASED")
                return@launch
            }

            val settings = settingsRepository.getSettings()
            val upiId = settings.upiId.ifBlank { "moviesoni@upi" }
            val payeeName = settings.payeeName.ifBlank { "MOVIE SONI ENTERTAINMENT" }
            val amount = movie.priceInr

            val orderResult = orderRepository.createOrder(
                userId = userId,
                customerName = userName,
                customerEmail = userEmail,
                movieId = movie.id,
                movieTitle = movie.title,
                moviePosterUrl = movie.posterUrl,
                amountInr = amount,
                upiId = upiId,
                payeeName = payeeName,
                upiUri = ""
            )

            if (orderResult.isFailure) {
                _uiState.value = PaymentUiState.Error("Failed to initiate order. Please try again.")
                return@launch
            }

            val orderId = orderResult.getOrThrow()
            currentOrderId = orderId

            val dynamicUpiUri = QrCodeGenerator.buildUpiUri(
                upiId = upiId,
                payeeName = payeeName,
                amountInr = amount,
                orderId = orderId,
                movieTitle = movie.title
            )

            // Update order with exact dynamic URI
            val qrBitmap = try {
                QrCodeGenerator.generateQrBitmap(dynamicUpiUri, 512)
            } catch (e: Exception) {
                _uiState.value = PaymentUiState.Error("Failed to generate UPI QR code")
                return@launch
            }

            _uiState.value = PaymentUiState.Ready(
                orderId = orderId,
                movie = movie,
                amountInr = amount,
                upiId = upiId,
                payeeName = payeeName,
                upiUri = dynamicUpiUri,
                qrBitmap = qrBitmap,
                transactionRef = null,
                status = "PENDING",
                rejectionReason = null,
                isSubmittingRef = false
            )

            // Start observing this order real-time for admin approval
            orderRepository.observeUserOrders(userId).collect { orders ->
                val thisOrder = orders.firstOrNull { it.id == orderId } ?: return@collect
                if (thisOrder.status == "APPROVED") {
                    _uiState.value = PaymentUiState.Completed(movie, orderId)
                } else if (_uiState.value is PaymentUiState.Ready) {
                    val current = _uiState.value as PaymentUiState.Ready
                    _uiState.value = current.copy(
                        status = thisOrder.status,
                        transactionRef = thisOrder.transactionRef,
                        rejectionReason = thisOrder.rejectionReason
                    )
                }
            }
        }
    }

    fun submitTransactionReference(reference: String) {
        val orderId = currentOrderId ?: return
        val current = _uiState.value as? PaymentUiState.Ready ?: return
        viewModelScope.launch {
            _uiState.value = current.copy(isSubmittingRef = true)
            val result = orderRepository.submitTransactionRef(orderId, reference)
            if (result.isSuccess) {
                _uiState.value = current.copy(
                    transactionRef = reference,
                    isSubmittingRef = false
                )
            } else {
                _uiState.value = current.copy(isSubmittingRef = false)
            }
        }
    }
}
