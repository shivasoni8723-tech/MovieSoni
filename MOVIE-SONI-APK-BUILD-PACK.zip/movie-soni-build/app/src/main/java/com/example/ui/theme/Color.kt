package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlack = Color(0xFF08080A)
val SurfaceDark = Color(0xFF131318)
val CardDark = Color(0xFF1B1B22)
val CardStroke = Color(0xFF2C2C38)

val BrandRed = Color(0xFFE50914)
val BrandRedDark = Color(0xFFB81D24)
val BrandGold = Color(0xFFF5A623)
val BrandGoldDark = Color(0xFFD48806)

val NeonBlue = Color(0xFF2979FF)
val NeonPurple = Color(0xFF8A2BE2)
val NeonPink = Color(0xFFFF1493)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFA0A0A8)
val TextSubtle = Color(0xFF70707C)

val StatusPending = Color(0xFFFFB020)
val StatusApproved = Color(0xFF00E676)
val StatusRejected = Color(0xFFFF1744)
