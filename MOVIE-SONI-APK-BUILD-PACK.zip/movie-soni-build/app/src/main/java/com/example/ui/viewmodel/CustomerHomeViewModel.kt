package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.Movie
import com.example.data.model.Purchase
import com.example.data.repository.MovieRepository
import com.example.data.repository.PurchaseRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private data class CatalogData(
    val movies: List<Movie>,
    val purchases: List<Purchase>,
    val settings: AppSettings
)

sealed interface HomeUiState {
    data object Loading : HomeUiState
    data class Success(
        val featuredMovies: List<Movie>,
        val latestMovies: List<Movie>,
        val trendingMovies: List<Movie>,
        val allMovies: List<Movie>,
        val comingSoonMovies: List<Movie>,
        val purchasedMovies: List<Movie>,
        val categories: List<String>,
        val selectedCategory: String,
        val searchQuery: String,
        val bannerMovie: Movie?,
        val isSyncing: Boolean
    ) : HomeUiState
    data class Empty(val message: String = "NO MOVIES AVAILABLE RIGHT NOW.") : HomeUiState
    data class Error(val message: String) : HomeUiState
}

class CustomerHomeViewModel(
    private val movieRepository: MovieRepository,
    private val purchaseRepository: PurchaseRepository,
    private val settingsRepository: SettingsRepository,
    private val userId: String
) : ViewModel() {

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val moviesFlow = movieRepository.observePublishedMovies()
    private val purchasesFlow = purchaseRepository.observeUserPurchases(userId)
    private val settingsFlow = settingsRepository.observeSettings()

    private val catalogDataFlow = combine(
        moviesFlow,
        purchasesFlow,
        settingsFlow
    ) { movies, purchases, settings ->
        CatalogData(movies, purchases, settings)
    }

    val uiState: StateFlow<HomeUiState> = combine(
        catalogDataFlow,
        _selectedCategory,
        _searchQuery,
        _isRefreshing
    ) { data, category, query, refreshing ->
        val movies = data.movies
        val purchases = data.purchases
        val settings = data.settings

        if (movies.isEmpty()) {
            return@combine HomeUiState.Empty("NO MOVIES AVAILABLE RIGHT NOW.")
        }

        val purchasedMovieIds = purchases.map { it.movieId }.toSet()
        val userPurchasedMovies = movies.filter { it.id in purchasedMovieIds }

        val bannerMovie = if (settings.bannerMovieId.isNullOrBlank()) {
            movies.firstOrNull { it.isFeatured } ?: movies.firstOrNull()
        } else {
            movies.firstOrNull { it.id == settings.bannerMovieId } ?: movies.firstOrNull()
        }

        val filteredByCategory = if (category == "All") {
            movies
        } else {
            movies.filter { it.category.equals(category, ignoreCase = true) }
        }

        val filteredByQuery = if (query.isBlank()) {
            filteredByCategory
        } else {
            filteredByCategory.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true) ||
                it.language.contains(query, ignoreCase = true)
            }
        }

        val featured = movies.filter { it.isFeatured }.ifEmpty { movies.take(5) }
        val latest = movies.filter { it.isLatest }.ifEmpty { movies.sortedByDescending { it.createdAt }.take(10) }
        val trending = movies.filter { it.isTrending }.ifEmpty { movies.reversed().take(10) }
        val comingSoon = movies.filter { it.isComingSoon }

        val allCategories = listOf("All") + movies.map { it.category.trim() }.filter { it.isNotBlank() }.distinct()

        HomeUiState.Success(
            featuredMovies = featured,
            latestMovies = latest,
            trendingMovies = trending,
            allMovies = filteredByQuery,
            comingSoonMovies = comingSoon,
            purchasedMovies = userPurchasedMovies,
            categories = allCategories,
            selectedCategory = category,
            searchQuery = query,
            bannerMovie = bannerMovie,
            isSyncing = refreshing
        )
    }.catch { error ->
        emit(HomeUiState.Error(error.localizedMessage ?: "Failed to synchronize movies"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState.Loading
    )

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            kotlinx.coroutines.delay(800)
            _isRefreshing.value = false
        }
    }
}
