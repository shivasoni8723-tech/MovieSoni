package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MovieSoniColorScheme = darkColorScheme(
    primary = BrandRed,
    onPrimary = TextWhite,
    primaryContainer = BrandRedDark,
    onPrimaryContainer = TextWhite,
    secondary = BrandGold,
    onSecondary = DeepBlack,
    secondaryContainer = CardDark,
    onSecondaryContainer = BrandGold,
    tertiary = NeonBlue,
    onTertiary = TextWhite,
    background = DeepBlack,
    onBackground = TextWhite,
    surface = SurfaceDark,
    onSurface = TextWhite,
    surfaceVariant = CardDark,
    onSurfaceVariant = TextMuted,
    outline = CardStroke,
    error = StatusRejected,
    onError = TextWhite
)

@Composable
fun MovieSoniTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MovieSoniColorScheme,
        typography = Typography,
        content = content
    )
}
