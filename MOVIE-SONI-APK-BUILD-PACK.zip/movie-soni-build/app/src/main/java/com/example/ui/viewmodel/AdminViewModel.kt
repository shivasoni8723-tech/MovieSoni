package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.Movie
import com.example.data.model.Order
import com.example.data.model.UserProfile
import com.example.data.repository.MovieRepository
import com.example.data.repository.OrderRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class AdminDashboardStats(
    val totalUsers: Int = 0,
    val totalPublishedMovies: Int = 0,
    val totalPurchases: Int = 0,
    val totalRevenueInr: Long = 0L,
    val pendingOrdersCount: Int = 0,
    val todaySalesInr: Long = 0L
)

sealed interface AdminUiState {
    data object Loading : AdminUiState
    data class Success(
        val stats: AdminDashboardStats,
        val movies: List<Movie>,
        val pendingOrders: List<Order>,
        val allOrders: List<Order>,
        val users: List<UserProfile>,
        val settings: AppSettings
    ) : AdminUiState
    data class Error(val message: String) : AdminUiState
}

class AdminViewModel(
    private val movieRepository: MovieRepository,
    private val orderRepository: OrderRepository,
    private val userRepository: UserRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    val uiState: StateFlow<AdminUiState> = combine(
        movieRepository.observeAllMoviesAdmin(),
        orderRepository.observeAllOrdersAdmin(),
        userRepository.observeAllUsersAdmin(),
        settingsRepository.observeSettings()
    ) { movies, orders, users, settings ->
        val approvedOrders = orders.filter { it.status == "APPROVED" }
        val pendingOrders = orders.filter { it.status == "PENDING" }

        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val todayRevenue = approvedOrders.filter { order ->
            val timestamp = order.updatedAt?.toDate()?.time ?: order.createdAt?.toDate()?.time ?: 0L
            timestamp >= startOfToday
        }.sumOf { it.amountInr }

        val stats = AdminDashboardStats(
            totalUsers = users.size,
            totalPublishedMovies = movies.count { it.isPublished },
            totalPurchases = approvedOrders.size,
            totalRevenueInr = approvedOrders.sumOf { it.amountInr },
            pendingOrdersCount = pendingOrders.size,
            todaySalesInr = todayRevenue
        )

        AdminUiState.Success(
            stats = stats,
            movies = movies.sortedByDescending { it.createdAt },
            pendingOrders = pendingOrders.sortedByDescending { it.createdAt },
            allOrders = orders.sortedByDescending { it.createdAt },
            users = users.sortedByDescending { it.createdAt },
            settings = settings
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AdminUiState.Loading
    )

    fun uploadMovie(movie: Movie, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = movieRepository.createMovie(movie)
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = "Movie uploaded successfully"
                onComplete(true)
            } else {
                _actionMessage.value = "Failed to upload movie: ${result.exceptionOrNull()?.message}"
                onComplete(false)
            }
        }
    }

    fun updateMovie(movieId: String, movie: Movie, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = movieRepository.updateMovie(movieId, movie)
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = "Movie updated successfully"
                onComplete(true)
            } else {
                _actionMessage.value = "Failed to update movie"
                onComplete(false)
            }
        }
    }

    fun deleteMovie(movieId: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = movieRepository.deleteMovie(movieId)
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = "Movie deleted"
            } else {
                _actionMessage.value = "Failed to delete movie"
            }
        }
    }

    fun togglePublishMovie(movie: Movie) {
        viewModelScope.launch {
            val updated = movie.copy(isPublished = !movie.isPublished)
            movieRepository.updateMovie(movie.id, updated)
        }
    }

    fun approvePayment(order: Order) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = orderRepository.approveOrder(
                orderId = order.id,
                userId = order.userId,
                movieId = order.movieId,
                movieTitle = order.movieTitle,
                moviePosterUrl = order.moviePosterUrl,
                amountPaid = order.amountInr
            )
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = "Payment approved and movie unlocked for ${order.customerName}"
            } else {
                _actionMessage.value = "Failed to approve payment: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun rejectPayment(orderId: String, reason: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = orderRepository.rejectOrder(orderId, reason)
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = "Payment rejected"
            } else {
                _actionMessage.value = "Failed to reject payment"
            }
        }
    }

    fun toggleBlockUser(userId: String, currentBlocked: Boolean) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = userRepository.toggleUserBlock(userId, !currentBlocked)
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = if (!currentBlocked) "User account suspended" else "User account unblocked"
            } else {
                _actionMessage.value = "Failed to change user status"
            }
        }
    }

    fun updateSettings(settings: AppSettings) {
        viewModelScope.launch {
            _isProcessing.value = true
            val result = settingsRepository.updateSettings(settings)
            _isProcessing.value = false
            if (result.isSuccess) {
                _actionMessage.value = "Settings saved successfully"
            } else {
                _actionMessage.value = "Failed to save settings"
            }
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }
}
