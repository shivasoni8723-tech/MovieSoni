package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class AppSettings(
    @DocumentId val id: String = "general",
    val upiId: String = "moviesoni@upi",
    val payeeName: String = "MOVIE SONI ENTERTAINMENT",
    val supportEmail: String = "support@moviesoni.com",
    val supportPhone: String? = "+91 98765 43210",
    val bannerMovieId: String? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
