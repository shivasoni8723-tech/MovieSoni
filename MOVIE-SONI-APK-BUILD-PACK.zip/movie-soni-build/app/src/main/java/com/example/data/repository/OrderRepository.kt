package com.example.data.repository

import com.example.data.model.Order
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class OrderRepository(private val db: FirebaseFirestore) {

    fun observeUserOrders(userId: String): Flow<List<Order>> {
        return db.collection("orders")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Order::class.java)
            }
    }

    fun observePendingOrdersAdmin(): Flow<List<Order>> {
        return db.collection("orders")
            .whereEqualTo("status", "PENDING")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Order::class.java)
            }
    }

    fun observeAllOrdersAdmin(): Flow<List<Order>> {
        return db.collection("orders")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Order::class.java)
            }
    }

    suspend fun getOrder(orderId: String): Order? {
        val path = "orders/$orderId"
        return try {
            val doc = db.collection("orders").document(orderId).get().await()
            if (doc.exists()) doc.toObject(Order::class.java) else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }

    suspend fun createOrder(
        userId: String,
        customerName: String,
        customerEmail: String,
        movieId: String,
        movieTitle: String,
        moviePosterUrl: String?,
        amountInr: Long,
        upiId: String,
        payeeName: String,
        upiUri: String
    ): Result<String> {
        val docRef = db.collection("orders").document()
        val path = docRef.path
        val payload = mapOf(
            "userId" to userId,
            "customerName" to customerName.ifBlank { "Customer" },
            "customerEmail" to customerEmail,
            "movieId" to movieId,
            "movieTitle" to movieTitle,
            "moviePosterUrl" to moviePosterUrl,
            "amountInr" to amountInr,
            "upiId" to upiId,
            "payeeName" to payeeName,
            "upiUri" to upiUri,
            "transactionRef" to null,
            "status" to "PENDING",
            "rejectionReason" to null,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun submitTransactionRef(orderId: String, transactionRef: String): Result<Unit> {
        val docRef = db.collection("orders").document(orderId)
        val path = docRef.path
        val payload = mapOf(
            "transactionRef" to transactionRef.trim(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun approveOrder(
        orderId: String,
        userId: String,
        movieId: String,
        movieTitle: String,
        moviePosterUrl: String?,
        amountPaid: Long
    ): Result<Unit> {
        val orderRef = db.collection("orders").document(orderId)
        val purchaseDocId = "${userId}_$movieId"
        val purchaseRef = db.collection("purchases").document(purchaseDocId)

        val batch = db.batch()
        batch.update(
            orderRef,
            mapOf(
                "status" to "APPROVED",
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        val purchasePayload = mapOf(
            "userId" to userId,
            "movieId" to movieId,
            "movieTitle" to movieTitle,
            "moviePosterUrl" to moviePosterUrl,
            "orderId" to orderId,
            "amountPaid" to amountPaid,
            "purchaseDate" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        batch.set(purchaseRef, purchasePayload)

        return try {
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, orderRef.path)
            Result.failure(e)
        }
    }

    suspend fun rejectOrder(orderId: String, reason: String): Result<Unit> {
        val orderRef = db.collection("orders").document(orderId)
        val path = orderRef.path
        val payload = mapOf(
            "status" to "REJECTED",
            "rejectionReason" to reason.trim(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            orderRef.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }
}
