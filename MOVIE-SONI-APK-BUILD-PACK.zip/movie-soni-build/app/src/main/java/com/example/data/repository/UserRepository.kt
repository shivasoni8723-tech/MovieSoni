package com.example.data.repository

import com.example.data.model.UserProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserRepository(private val db: FirebaseFirestore) {

    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        return db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) snapshot.toObject(UserProfile::class.java) else null
            }
    }

    fun observeAllUsersAdmin(): Flow<List<UserProfile>> {
        return db.collection("users")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(UserProfile::class.java)
            }
    }

    suspend fun syncUserProfile(
        userId: String,
        email: String,
        displayName: String,
        photoUrl: String?
    ): Result<UserProfile> {
        val docRef = db.collection("users").document(userId)
        val path = docRef.path

        return try {
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) {
                val payload = mapOf(
                    "userId" to userId,
                    "email" to email,
                    "displayName" to displayName.ifBlank { "Customer" },
                    "photoUrl" to photoUrl,
                    "role" to "customer",
                    "isBlocked" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
                Result.success(
                    UserProfile(
                        id = userId,
                        userId = userId,
                        email = email,
                        displayName = displayName.ifBlank { "Customer" },
                        photoUrl = photoUrl,
                        role = "customer",
                        isBlocked = false
                    )
                )
            } else {
                val existing = snapshot.toObject(UserProfile::class.java)
                val updatePayload = mapOf(
                    "displayName" to displayName.ifBlank { existing?.displayName ?: "Customer" },
                    "photoUrl" to (photoUrl ?: existing?.photoUrl),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.update(updatePayload).await()
                Result.success(
                    existing?.copy(
                        displayName = displayName.ifBlank { existing.displayName },
                        photoUrl = photoUrl ?: existing.photoUrl
                    ) ?: UserProfile(id = userId, userId = userId, email = email, displayName = displayName)
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleUserBlock(userId: String, isBlocked: Boolean): Result<Unit> {
        val docRef = db.collection("users").document(userId)
        val path = docRef.path
        return try {
            docRef.update(
                mapOf(
                    "isBlocked" to isBlocked,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun checkIsAdmin(userId: String, email: String?): Boolean {
        if (email.equals("zoyaaiassistant0@gmail.com", ignoreCase = true)) {
            return true
        }
        val path = "admins/$userId"
        return try {
            val doc = db.collection("admins").document(userId).get().await()
            doc.exists()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            false
        }
    }
}
