package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Movie
import com.example.ui.components.MovieSoniLogo
import com.example.ui.theme.BrandGold
import com.example.ui.theme.BrandRed
import com.example.ui.theme.CardDark
import com.example.ui.theme.CardStroke
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.StatusApproved
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.AdminViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMovieUploadScreen(
    movieToEdit: Movie?,
    viewModel: AdminViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isProcessing by viewModel.isProcessing.collectAsState()

    var title by remember { mutableStateOf(movieToEdit?.title ?: "") }
    var description by remember { mutableStateOf(movieToEdit?.description ?: "") }
    var posterUrl by remember { mutableStateOf(movieToEdit?.posterUrl ?: "") }
    var videoUrl by remember { mutableStateOf(movieToEdit?.videoUrl ?: "") }
    var trailerUrl by remember { mutableStateOf(movieToEdit?.trailerUrl ?: "") }
    var durationMinutesText by remember { mutableStateOf(movieToEdit?.durationMinutes?.toString() ?: "120") }
    var language by remember { mutableStateOf(movieToEdit?.language ?: "Hindi") }
    var category by remember { mutableStateOf(movieToEdit?.category ?: "Action") }
    var priceText by remember { mutableStateOf(movieToEdit?.priceInr?.toString() ?: "199") }
    var releaseDate by remember { mutableStateOf(movieToEdit?.releaseDate ?: "2025") }

    var isPublished by remember { mutableStateOf(movieToEdit?.isPublished ?: true) }
    var isFeatured by remember { mutableStateOf(movieToEdit?.isFeatured ?: true) }
    var isLatest by remember { mutableStateOf(movieToEdit?.isLatest ?: true) }
    var isTrending by remember { mutableStateOf(movieToEdit?.isTrending ?: false) }
    var isComingSoon by remember { mutableStateOf(movieToEdit?.isComingSoon ?: false) }

    BackHandler { onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepBlack),
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("upload_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextWhite
                        )
                    }
                },
                title = {
                    Text(
                        text = if (movieToEdit != null) "Edit Movie" else "Upload Movie",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    MovieSoniLogo(size = 30, modifier = Modifier.padding(end = 12.dp))
                }
            )
        },
        containerColor = DeepBlack,
        modifier = modifier.testTag("admin_upload_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Quick Sample Preset Button
            if (movieToEdit == null) {
                OutlinedButton(
                    onClick = {
                        title = "Shershaah: The Brave Hearts"
                        description = "An adrenaline-fueled cinematic action masterpiece chronicling extraordinary courage, patriotism, and high-stakes combat on the snowy mountain frontiers."
                        posterUrl = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80"
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
                        trailerUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                        durationMinutesText = "138"
                        language = "Hindi"
                        category = "Action"
                        priceText = "199"
                        releaseDate = "2025"
                        isPublished = true
                        isFeatured = true
                        isLatest = true
                        isTrending = true
                        Toast.makeText(context, "Filled with sample movie data", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandGold),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Auto-Fill Sample Blockbuster Movie", fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Movie Poster Preview
            if (posterUrl.isNotBlank()) {
                Surface(
                    color = CardDark,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        AsyncImage(
                            model = posterUrl,
                            contentDescription = "Poster Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "Poster Preview",
                                color = TextWhite,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Form Fields
            MovieFormField("Movie Title *", title) { title = it }
            MovieFormField("Description / Synopsis *", description, singleLine = false) { description = it }
            MovieFormField("Poster Image URL (HTTPS) *", posterUrl) { posterUrl = it }
            MovieFormField("Movie Video Stream URL (MP4 / CDN) *", videoUrl) { videoUrl = it }
            MovieFormField("Trailer Video URL (Optional)", trailerUrl) { trailerUrl = it }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    MovieFormField("Duration (Mins)", durationMinutesText, keyboardType = KeyboardType.Number) {
                        durationMinutesText = it.filter { c -> c.isDigit() }
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    MovieFormField("Price (INR ₹)", priceText, keyboardType = KeyboardType.Number) {
                        priceText = it.filter { c -> c.isDigit() }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    MovieFormField("Language (e.g. Hindi)", language) { language = it }
                }
                Box(modifier = Modifier.weight(1f)) {
                    MovieFormField("Genre (e.g. Action)", category) { category = it }
                }
            }

            MovieFormField("Release Year / Date", releaseDate) { releaseDate = it }

            Spacer(modifier = Modifier.height(16.dp))

            // OTT Flags
            Text(
                text = "DISTRIBUTION & VISIBILITY",
                color = BrandGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = CardDark,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    ToggleRow("Publish Live to Customers", "Immediately visible on Home Screen", isPublished) { isPublished = it }
                    ToggleRow("Featured Movie", "Showcase on top hero section", isFeatured) { isFeatured = it }
                    ToggleRow("Latest Release", "Feature in Latest Releases carousel", isLatest) { isLatest = it }
                    ToggleRow("Trending Movie", "Feature in Trending Movies list", isTrending) { isTrending = it }
                    ToggleRow("Coming Soon", "Tag as Upcoming Premiere", isComingSoon) { isComingSoon = it }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Button
            Button(
                onClick = {
                    if (title.isBlank() || description.isBlank() || posterUrl.isBlank() || videoUrl.isBlank()) {
                        Toast.makeText(context, "Please fill in all required fields (*)", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    val duration = durationMinutesText.toLongOrNull() ?: 120L
                    val price = priceText.toLongOrNull() ?: 0L

                    val movie = (movieToEdit ?: Movie()).copy(
                        title = title.trim(),
                        description = description.trim(),
                        posterUrl = posterUrl.trim(),
                        videoUrl = videoUrl.trim(),
                        trailerUrl = trailerUrl.trim().ifBlank { null },
                        durationMinutes = duration,
                        language = language.trim().ifBlank { "Hindi" },
                        category = category.trim().ifBlank { "Action" },
                        priceInr = price,
                        releaseDate = releaseDate.trim().ifBlank { "2025" },
                        isPublished = isPublished,
                        isFeatured = isFeatured,
                        isLatest = isLatest,
                        isTrending = isTrending,
                        isComingSoon = isComingSoon
                    )

                    if (movieToEdit != null) {
                        viewModel.updateMovie(movieToEdit.id, movie) { success ->
                            if (success) onBack()
                        }
                    } else {
                        viewModel.uploadMovie(movie) { success ->
                            if (success) onBack()
                        }
                    }
                },
                enabled = !isProcessing,
                colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("publish_movie_button")
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        color = TextWhite,
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (movieToEdit != null) "SAVE & UPDATE MOVIE" else "PUBLISH TO CLOUD LIVE SYNC",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun MovieFormField(
    label: String,
    value: String,
    singleLine: Boolean = true,
    keyboardType: KeyboardType = KeyboardType.Text,
    onValueChange: (String) -> Unit
) {
    Column(modifier = Modifier.padding(bottom = 12.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            singleLine = singleLine,
            maxLines = if (singleLine) 1 else 4,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandGold,
                unfocusedBorderColor = CardStroke,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedLabelColor = BrandGold,
                unfocusedLabelColor = TextMuted,
                focusedContainerColor = CardDark,
                unfocusedContainerColor = CardDark
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = TextMuted, fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = TextWhite,
                checkedTrackColor = BrandRed,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = DeepBlack
            )
        )
    }
}
