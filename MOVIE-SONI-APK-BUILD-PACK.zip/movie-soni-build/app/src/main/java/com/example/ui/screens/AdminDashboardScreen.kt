package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AppSettings
import com.example.data.model.Movie
import com.example.data.model.Order
import com.example.data.model.UserProfile
import com.example.ui.components.LiveSyncBadge
import com.example.ui.components.MovieSoniLogo
import com.example.ui.theme.BrandGold
import com.example.ui.theme.BrandRed
import com.example.ui.theme.CardDark
import com.example.ui.theme.CardStroke
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.StatusApproved
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.AdminDashboardStats
import com.example.ui.viewmodel.AdminUiState
import com.example.ui.viewmodel.AdminViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: AdminViewModel,
    onBack: () -> Unit,
    onNavigateToUploadMovie: (Movie?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val actionMessage by viewModel.actionMessage.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Overview", "Pending Orders", "Movies", "Users", "Settings")

    BackHandler { onBack() }

    LaunchedEffect(actionMessage) {
        actionMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearActionMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepBlack),
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Customer View",
                            tint = TextWhite
                        )
                    }
                },
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ADMIN PANEL",
                                color = BrandRed,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            LiveSyncBadge()
                        }
                        Text(
                            text = "MOVIE SONI Real-Time Backend",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                actions = {
                    MovieSoniLogo(size = 30, modifier = Modifier.padding(end = 12.dp))
                }
            )
        },
        floatingActionButton = {
            if (selectedTab == 2) {
                FloatingActionButton(
                    onClick = { onNavigateToUploadMovie(null) },
                    containerColor = BrandRed,
                    contentColor = TextWhite,
                    modifier = Modifier.testTag("admin_add_movie_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Upload Movie")
                }
            }
        },
        containerColor = DeepBlack,
        modifier = modifier.testTag("admin_dashboard_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Scrollable Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = CardDark,
                contentColor = BrandGold,
                edgePadding = 12.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) BrandGold else TextMuted
                            )
                        }
                    )
                }
            }

            when (val state = uiState) {
                is AdminUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = BrandRed)
                    }
                }

                is AdminUiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = state.message, color = StatusRejected)
                    }
                }

                is AdminUiState.Success -> {
                    when (selectedTab) {
                        0 -> AdminOverviewTab(
                            stats = state.stats,
                            pendingOrders = state.pendingOrders,
                            onApproveOrder = { viewModel.approvePayment(it) },
                            onRejectOrder = { orderId, reason -> viewModel.rejectPayment(orderId, reason) },
                            onSwitchToMovies = { selectedTab = 2 },
                            onSwitchToOrders = { selectedTab = 1 },
                            onUploadMovie = { onNavigateToUploadMovie(null) }
                        )

                        1 -> AdminOrdersTab(
                            pendingOrders = state.pendingOrders,
                            allOrders = state.allOrders,
                            onApprove = { viewModel.approvePayment(it) },
                            onReject = { orderId, reason -> viewModel.rejectPayment(orderId, reason) }
                        )

                        2 -> AdminMoviesTab(
                            movies = state.movies,
                            onTogglePublish = { viewModel.togglePublishMovie(it) },
                            onEdit = { onNavigateToUploadMovie(it) },
                            onDelete = { viewModel.deleteMovie(it.id) },
                            onUploadNew = { onNavigateToUploadMovie(null) }
                        )

                        3 -> AdminUsersTab(
                            users = state.users,
                            onToggleBlock = { uid, blocked -> viewModel.toggleBlockUser(uid, blocked) }
                        )

                        4 -> AdminSettingsTab(
                            settings = state.settings,
                            onSaveSettings = { viewModel.updateSettings(it) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminOverviewTab(
    stats: AdminDashboardStats,
    pendingOrders: List<Order>,
    onApproveOrder: (Order) -> Unit,
    onRejectOrder: (String, String) -> Unit,
    onSwitchToMovies: () -> Unit,
    onSwitchToOrders: () -> Unit,
    onUploadMovie: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "LIVE PLATFORM TELEMETRY",
            color = BrandGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Grid of 6 Statistics Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Total Users",
                value = stats.totalUsers.toString(),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Published Movies",
                value = stats.totalPublishedMovies.toString(),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Total Purchases",
                value = stats.totalPurchases.toString(),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Total Revenue",
                value = "₹${stats.totalRevenueInr}",
                highlightGold = true,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Pending Approvals",
                value = stats.pendingOrdersCount.toString(),
                highlightRed = stats.pendingOrdersCount > 0,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Today's Sales",
                value = "₹${stats.todaySalesInr}",
                highlightGold = true,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Actions Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onUploadMovie,
                colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Upload Movie", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onSwitchToOrders,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("View Orders (${stats.pendingOrdersCount})", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Pending Approval Alert Section
        Text(
            text = "ACTION REQUIRED: PENDING PAYMENTS (${pendingOrders.size})",
            color = if (pendingOrders.isNotEmpty()) BrandGold else TextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (pendingOrders.isEmpty()) {
            Surface(
                color = CardDark,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "No pending payment verification requests. All transactions are up-to-date.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            pendingOrders.take(3).forEach { order ->
                PendingOrderCard(
                    order = order,
                    onApprove = { onApproveOrder(order) },
                    onReject = { reason -> onRejectOrder(order.id, reason) }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    highlightGold: Boolean = false,
    highlightRed: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CardDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            when {
                highlightRed -> BrandRed
                highlightGold -> BrandGold.copy(alpha = 0.5f)
                else -> CardStroke
            }
        ),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = when {
                    highlightRed -> BrandRed
                    highlightGold -> BrandGold
                    else -> TextWhite
                },
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun PendingOrderCard(
    order: Order,
    onApprove: () -> Unit,
    onReject: (String) -> Unit
) {
    var showRejectDialog by remember { mutableStateOf(false) }
    var rejectReason by remember { mutableStateOf("Invalid UTR / Transaction not received") }

    Surface(
        color = CardDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_pending_order_${order.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = order.movieTitle,
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "₹${order.amountInr}",
                    color = BrandGold,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Customer: ${order.customerName} (${order.customerEmail})", color = TextMuted, fontSize = 11.sp)
            Text(
                text = "Submitted UTR: ${order.transactionRef ?: "Not entered yet"}",
                color = if (order.transactionRef != null) StatusApproved else StatusPending,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(text = "Order ID: ${order.id}", color = TextMuted, fontSize = 10.sp)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showRejectDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejected),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reject", fontSize = 12.sp)
                }

                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusApproved),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Approve & Unlock", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showRejectDialog) {
        AlertDialog(
            onDismissRequest = { showRejectDialog = false },
            title = { Text("Reject Payment", color = TextWhite) },
            text = {
                Column {
                    Text("Provide reason for rejection:", color = TextMuted, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectReason,
                        onValueChange = { rejectReason = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            containerColor = CardDark,
            confirmButton = {
                Button(
                    onClick = {
                        showRejectDialog = false
                        onReject(rejectReason)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandRed)
                ) {
                    Text("Confirm Reject")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRejectDialog = false }) {
                    Text("Cancel", color = TextWhite)
                }
            }
        )
    }
}

@Composable
private fun AdminOrdersTab(
    pendingOrders: List<Order>,
    allOrders: List<Order>,
    onApprove: (Order) -> Unit,
    onReject: (String, String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "ALL TRANSACTION ORDERS (${allOrders.size})",
                color = BrandGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
        }

        if (allOrders.isEmpty()) {
            item {
                Text("No orders placed yet.", color = TextMuted, fontSize = 14.sp)
            }
        } else {
            items(allOrders, key = { it.id }) { order ->
                if (order.status == "PENDING") {
                    PendingOrderCard(
                        order = order,
                        onApprove = { onApprove(order) },
                        onReject = { reason -> onReject(order.id, reason) }
                    )
                } else {
                    Surface(
                        color = CardDark,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(order.movieTitle, color = TextWhite, fontWeight = FontWeight.Bold)
                                Text("${order.customerName} • ₹${order.amountInr}", color = TextMuted, fontSize = 12.sp)
                                if (order.transactionRef != null) {
                                    Text("UTR: ${order.transactionRef}", color = BrandGold, fontSize = 11.sp)
                                }
                            }
                            Surface(
                                color = if (order.status == "APPROVED") StatusApproved.copy(alpha = 0.2f) else StatusRejected.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = order.status,
                                    color = if (order.status == "APPROVED") StatusApproved else StatusRejected,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminMoviesTab(
    movies: List<Movie>,
    onTogglePublish: (Movie) -> Unit,
    onEdit: (Movie) -> Unit,
    onDelete: (Movie) -> Unit,
    onUploadNew: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CATALOG MOVIES (${movies.size})",
                    color = BrandGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
                Button(
                    onClick = onUploadNew,
                    colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Upload Movie", fontSize = 11.sp)
                }
            }
        }

        if (movies.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "NO MOVIES PUBLISHED YET",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Upload a movie to synchronize it to customer home screens immediately.",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onUploadNew,
                            colors = ButtonDefaults.buttonColors(containerColor = BrandRed)
                        ) {
                            Text("Upload First Movie")
                        }
                    }
                }
            }
        } else {
            items(movies, key = { it.id }) { movie ->
                AdminMovieItem(
                    movie = movie,
                    onTogglePublish = { onTogglePublish(movie) },
                    onEdit = { onEdit(movie) },
                    onDelete = { onDelete(movie) }
                )
            }
        }
    }
}

@Composable
private fun AdminMovieItem(
    movie: Movie,
    onTogglePublish: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = CardDark,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (movie.posterUrl.isNotBlank()) {
                AsyncImage(
                    model = movie.posterUrl,
                    contentDescription = movie.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(width = 50.dp, height = 70.dp)
                        .clip(RoundedCornerShape(6.dp))
                )
                Spacer(modifier = Modifier.width(12.dp))
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = movie.title,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${movie.category} • ${movie.language} • ₹${movie.priceInr}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = if (movie.isPublished) StatusApproved.copy(alpha = 0.2f) else StatusPending.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (movie.isPublished) "PUBLISHED" else "DRAFT",
                            color = if (movie.isPublished) StatusApproved else StatusPending,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            IconButton(onClick = onTogglePublish) {
                Icon(
                    imageVector = if (movie.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    contentDescription = "Toggle Publish",
                    tint = if (movie.isPublished) StatusApproved else TextMuted
                )
            }

            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = BrandGold)
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRejected)
            }
        }
    }
}

@Composable
private fun AdminUsersTab(
    users: List<UserProfile>,
    onToggleBlock: (String, Boolean) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "REGISTERED USERS (${users.size})",
                color = BrandGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
        }

        items(users, key = { it.userId }) { user ->
            Surface(
                color = CardDark,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardStroke),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(BrandRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.displayName.take(1).uppercase().ifBlank { "U" },
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(user.displayName.ifBlank { "User" }, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(user.email, color = TextMuted, fontSize = 11.sp)
                        Text(user.phoneNumber.orEmpty().ifBlank { "No phone linked" }, color = TextMuted, fontSize = 10.sp)
                    }

                    IconButton(onClick = { onToggleBlock(user.userId, user.isBlocked) }) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = "Toggle Block",
                            tint = if (user.isBlocked) StatusRejected else TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminSettingsTab(
    settings: AppSettings,
    onSaveSettings: (AppSettings) -> Unit
) {
    var upiId by remember(settings.upiId) { mutableStateOf(settings.upiId) }
    var payeeName by remember(settings.payeeName) { mutableStateOf(settings.payeeName) }
    var bannerMovieId by remember(settings.bannerMovieId) { mutableStateOf(settings.bannerMovieId ?: "") }
    var supportEmail by remember(settings.supportEmail) { mutableStateOf(settings.supportEmail) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "UPI PAYMENT GATEWAY SETTINGS",
            color = BrandGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = upiId,
            onValueChange = { upiId = it },
            label = { Text("Receiver UPI ID (VPA)") },
            placeholder = { Text("moviesoni@upi") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandGold,
                unfocusedBorderColor = CardStroke,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedLabelColor = BrandGold,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = payeeName,
            onValueChange = { payeeName = it },
            label = { Text("Payee Business Name") },
            placeholder = { Text("MOVIE SONI ENTERTAINMENT") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandGold,
                unfocusedBorderColor = CardStroke,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedLabelColor = BrandGold,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "PLATFORM SETTINGS",
            color = BrandGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = bannerMovieId,
            onValueChange = { bannerMovieId = it },
            label = { Text("Hero Banner Movie ID (Optional)") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandGold,
                unfocusedBorderColor = CardStroke,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedLabelColor = BrandGold,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = supportEmail,
            onValueChange = { supportEmail = it },
            label = { Text("Support Email") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandGold,
                unfocusedBorderColor = CardStroke,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedLabelColor = BrandGold,
                unfocusedLabelColor = TextMuted
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                onSaveSettings(
                    settings.copy(
                        upiId = upiId.trim(),
                        payeeName = payeeName.trim(),
                        bannerMovieId = bannerMovieId.trim().ifBlank { null },
                        supportEmail = supportEmail.trim()
                    )
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save Platform Settings", fontWeight = FontWeight.Bold)
        }
    }
}
