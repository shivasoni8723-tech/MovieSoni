package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Movie
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class MovieRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun admin_canCreateMovie() = runBlocking {
        signInTestUser(ADMIN_EMAIL)
        val repository = MovieRepository(firestore)
        val movie = Movie(
            title = "Test Movie ${UUID.randomUUID()}",
            description = "A great test movie",
            posterUrl = "https://example.com/poster.jpg",
            videoUrl = "https://example.com/video.mp4",
            durationMinutes = 120,
            language = "Hindi",
            category = "Action",
            priceInr = 49,
            isPublished = true
        )

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createMovie(movie)
        }
        assertNotNull("Repository createMovie must return a non-null Result", result)
    }

    @Test
    fun customer_cannotCreateMovie() = runBlocking {
        signInTestUser(CUSTOMER_EMAIL)
        val repository = MovieRepository(firestore)
        val movie = Movie(
            title = "Unauthorized Movie",
            description = "This should fail",
            posterUrl = "https://example.com/poster.jpg",
            videoUrl = "https://example.com/video.mp4",
            durationMinutes = 100,
            language = "Hindi",
            category = "Action",
            priceInr = 29,
            isPublished = true
        )

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createMovie(movie)
        }
        assertTrue("Customer movie creation should fail", result.isFailure)
    }

    @Test
    fun unauthenticated_cannotObserveMovies() = runBlocking {
        auth.signOut()
        val repository = MovieRepository(firestore)
        var caughtException: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observePublishedMovies().first()
            }
        } catch (e: Exception) {
            caughtException = e.unwrapFirestoreException() ?: e
        }
        assertNotNull("Unauthenticated observe should fail", caughtException)
    }

    private companion object {
        const val ADMIN_EMAIL = "zoyaaiassistant0@gmail.com"
        const val CUSTOMER_EMAIL = "customer@example.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
